<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Railway E-Ticket Service</title>
  </head>
  <body>
    <h1>Welcome To Railway E-Ticket Service </h1>
    <div class = "main">
      <a href="#">HOME</a>
      <a href="./databases_pages/login.php">Log In</a>
      <a href="./databases_pages/admin_login.php">Admin</a>
      <a href="./databases_pages/contactus.php">Contact Us</a>
    </div>

  </body>

</html>
