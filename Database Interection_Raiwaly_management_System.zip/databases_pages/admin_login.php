<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
  </style>
    <title>LOG IN</title>
  </head>
  <body>
    <a href="../index.php">HOME</a>
		<center>
		<div class="Admin">
			<h1>Administrator Log In</h1>
			<form action = "./Admin_Signin.php" method = "post">
				<input type="text" name="admin_name" placeholder="admin"><br>
				<input type="password"name="pass" placeholder="password"><br><br>
				<input type="submit" name = 'Admin_login' value="Log In"><br><br>

		</div>
 </form>
</center>
  </body>
</html>
