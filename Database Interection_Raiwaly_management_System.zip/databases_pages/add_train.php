<?php
session_start();
if(!isset($_SESSION['admin_name'])){
  header("Location: ./admin_login.php");
}

 ?>
 <!DOCTYPE html>
 <html lang="en" dir="ltr">
   <head>
     <meta charset="utf-8">
     <title>NEW TRAIN</title>
   </head>
   <body><center>
     <div class = " registration">
       <h1>Add New Train!</h1>

     <form action="./verifytrain.php" method="post" >

     <label >Train ID:</label>
     <input type="number" name="trainid" placeholder="Enter ID"><br><br>

     <label >Train Name:</label>
     <input type="text" name="trainname" placeholder="Enter Train Name"><br><br>

     <label >Start Location: </label>
     <input type="text"  name="startplace" placeholder="Enter place"><br><br>

     <label >End Location:</label>
     <input type="text"  name="endplace" placeholder=" Enter place"><br><br>

     <label > Total Seats:</label>
     <input type="number"  name="totalseat"><br><br>

     <label >Available Seats:</label>
     <input type="number"  name="availableseat"><br><br>

     <label >Departure Time</label>
     <input type="time" name="departuretime"><br><br>

     <label >Arrival Time</label>
     <input type="time" name="arrivaltime"><br><br>
     <input type="submit" name= "add" value="Add Train"><br>
     </div>
     </form>
 </center>
   </body>
 </html>
