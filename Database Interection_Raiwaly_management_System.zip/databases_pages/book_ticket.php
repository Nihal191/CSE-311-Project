<?php
session_start();
if(!isset($_SESSION['email'])){
  header("Location: ./login.php");
}
?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>BOOK TICKET</title>
  </head>
  <body>
    <center>
    <h1>Book Ticket</h1>
    <form action="#" method="post" >

    <label ><b>Name:</b></label>
    <input type="text" name="name" placeholder="Enter Name"><br><br>

    <label >Start Location:</label>
    <input type="text" name="startlocation" placeholder="place"><br><br>

    <label >End Location:</label>
    <input type="text" name="endlocation" placeholder="place"><br><br>

    <label > Journey Date: </label>
    <input type="date"  name="jdate" ><br><br>


    <input type="submit" name= "register" value="Next-->"><br><br>
  </form>

  <h3><a href="./welcome.php"><button type="button" name="back">Back</button></a></h3>
</center>

  </body>
</html>
