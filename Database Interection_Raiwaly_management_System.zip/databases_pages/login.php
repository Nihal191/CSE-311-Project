<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
  </style>
    <title>LOG IN</title>
  </head>
  <body>
    <a href="../index.php">HOME</a>
		<center>
		<div class="container">
			<h1>LOG IN</h1>
			<form name = "loginform" action = "./signin.php" method = "post">
				<input type="email" name="email" placeholder="E-mail"><br>
				<input type="password"name="password" placeholder="Password"><br><br>
				<input type="submit" name = 'login' value="Log In"><br><br>

		</div>
 </form>
 <h4>Don't have an account!</h4>
	<a  href="./registration.php">Create an account</a>
</center>
  </body>
</html>
