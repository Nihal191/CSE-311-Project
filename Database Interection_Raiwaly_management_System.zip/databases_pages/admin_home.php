<?php
session_start();
if(!isset($_SESSION['admin_name'])){
  header("Location: ./admin_login.php");
}
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Administrator</title>
  </head>
  <body>
    <h1>Welcome ! Admin</h1>
    <a href="./view_user_list.php">USER LIST</a><br><br>
    <a href="./train_list.php">TRAIN LIST</a><br><br>
    <a href="./add_train.php">ADD NEW TRAIN</a><br><br>
    <a href="#">View Users Review</a>

<br><br>
    <a href="./admin_login.php">Logout</a>
  </body>
</html>
