<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>CONTACT US</title>
  </head>
  <body>
    <div class = "main">
      <a href="../index.php">HOME</a>
      <a href="./login.php">Log In</a>
      <a href="./admin_login.php">Admin</a>
    <a href="#">Contact Us </a>
  </div>
  <div class = "contact">
    <h1>CONTACT US</h1>
    <h2>For Refund Purposes</h2>
    <p>Please email us including the station name from where you want travel.</p>
    <h2>For Technical Support</h2>
    Email: abcdef1234@gmail.com<br>
    Phone Number:01406849359

    <br><br><br>

    Username:
    <input type="text" name="name" placeholder="Name"><br>
    Review:
    <input type="text" name="review" placeholder="Give Your Review">

  </div>

  </body>
</html>
