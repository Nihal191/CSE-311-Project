<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>CREATE ACCOUNT</title>
  </head>
  <body><center>
    <div class = " registration">
      <h1>Create Account</h1>

    <form action="./SignUp.php" method="post" >

    <label ><b>Name:</b></label>
    <input type="text" name="name" placeholder="Enter Name"><br>

    <label >Email:</label>
    <input type="email" name="email" placeholder="Email address"><br>

    <label > Phone Number: </label>
    <input type="phone"  name="phone" placeholder="Phone Numeber"><br>

    <label >Confirm phone:</label>
    <input type="phone"  name="Confirmphone" placeholder="Re Enter Phone Number"><br>

    <label > Date of Birth:</label>
    <input type="date"  name="DOB" placeholder="Enter Date of Birth"><br>

    <label >Gender: </label>
     Female<input type="radio"  name="gender" value = "Female">
     Male<input type="radio"  name="gender" value = "Male">
     Other<input type="radio"  name="gender" value = "Other"><br>

    <label >Address:</label>
    <input type="textarea"  name="Address" placeholder="Enter Address"><br>

    <label >Password:</label>
    <input type="password" name="Password" placeholder="Enter Password"><br>

    <label >Confirm password:</label>
    <input type="password"  name="Confirmpassword" placeholder="Re-Enter Password"><br><br>
    <input type="submit" name= "register" value="Submit"><br>
    <br>Already Registered?<br>
    <br><a  href="./login.php">Log In</a>
    </div>
    </form>
</center>
  </body>
</html>
