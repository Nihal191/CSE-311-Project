<?php

session_start();
if(!isset($_SESSION['email'])){
  header("Location: ./login.php");
}
?>


<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>WELCOME PAGE</title>
  </head>
  <body>
    <center><h1>WELCOME</h1>
    <?=$_SESSION['email'];?><br></center><br>

    <div class = "main">
      <a href="../index.php">HOME</a>
      <a href="./logout.php">Logout</a>
      <a href="./user_profile.php">Profile</a>
      <a href="./book_ticket.php">Book Ticket</a>
    </div>
    <center>
    <div class = "Tour">
      <h1>Route info</h1>

    <form action="./verifyroute.php" method="post" >

      <label>FROM:</label>
      <select name ='from'>
        <option >SELECT PLACE</option>
        <?php
        include("./connect_database.php");
        $place_list = "select * from Places order by place_name asc";
        $place = mysqli_query($connect,$place_list);
        while($line= mysqli_fetch_assoc($place)){
          ?>
           <option value="<?=$line['place_name'];?>">
             <?=$line['place_name'];?>
           </option>
         <?php } ?>

   </select>
<br><br>
  <label>TO:</label>
  <select name ='to'>
    <option >SELECT PLACE</option>
    <?php
    $place_list = "select * from Places order by place_name asc";
    $place = mysqli_query($connect,$place_list);
    while($line= mysqli_fetch_assoc($place)){
      ?>
       <option value="<?=$line['place_name'];?>">
         <?=$line['place_name'];?>
       </option>
     <?php } ?>
  </select>
<br><br>
    <label >DATE:</label>
    <input type="date"  name="date" placeholder="Enter Date of Birth"><br><br>
    <label>CLASS:</label>
  <select  name ='class'>
    <option >SELECT CLASS</option>
    <option value="AC">AC</option>
    <option value="SHOVON">SHOVON</option>
    <option value="SNIGDHA">SNIGDHA</option>
    <option value="S_CHAIR">S_CHAIR</option>
  </select>
  <br><br><br>
    <input type="submit" name= "submit" value="Check"><br>
  </form>
</center>
  <br><br>
</div>

  </body>
</html>
