<?php
session_start();
if(!isset($_SESSION['email'])){
  header("Location: ./login.php");
}
?>
<?php
include("./connect_database.php");
  $user_email = $_GET['email'];
  $run_update_sql = "select * from passenger";
  $get_user_update = mysqli_query($connect, $run_update_sql);

  $row = mysqli_fetch_assoc($get_user_update);
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Update Profile</title>
  </head>
  <body>
    <center>
    <h1>Edit User Information</h1>
  <form  action="./update_user_profile.php?id=<?=$row['passenger_id'];?>" method="post">
    User Name : <input type="text" name="uname" value="<?=$row['passenger_name'];?>"><br><br>
    User Email :<input type="email" name="uemail" value="<?=$row['email'];?>"><br><br>
    User Phone Number : <input type="phone" name="phone_number" value="<?=$row['phone_number'];?>"><br><br>
    User Date of Birth : <input type="date" name="dob" value="<?=$row['date_of_birth'];?>"><br><br>
    User Address : <input type="textarea" name="address" value="<?=$row['address'];?>"><br><br>
    User Password : <input type="password" name="upass" value="<?=$row['password'];?>"><br><br>

    <input type="submit" name="update" value="Update">
  </form>
  </center>

  </body>
</html>
